<template>
    <div class="about">
        <div class="container vision">
            <div class="row">
                <div class="col-md-6 vision-img">
                    <img src="../assets/Asset-49.svg" alt="">
                </div>
                <div class="col-md-6 vesion-text">
                    <h1 class="h1-text">Our Vision</h1>
                    <p class="p-text">Everyday travel, solved! We are setting a trendier trend by transforming the daily travel ‘culture’ into something better. We call it Ontrack.</p>
                </div>
            </div>
        </div>
        <div class="mission-box2">
                
        </div>
        <div class="mission-box1">
        <div class="container mission">
            <div class="row">
                <div class="col-md-6 vesion-text">
                    <h1 class="h1-mission">Our Mission</h1>
                    <p class="p-mission">Travel goals: We want day-to-day travellers to ride with us on our monthly rented and utility bikes. Our aim is to make their travel experience uncomplicated and enjoyable.</p>
                </div>
                <div class="col-md-6 mission-img">
                    <img src="../assets/about-mission1.svg" alt="">
                </div>
            </div>
        </div>
        </div>
        <div class="container affordable">
            <div class="row">
                <div class="col-md-6 affordable-img">
                    <img src="../assets/Asset-49.svg" alt="">
                </div>
                <div class="col-md-6 vesion-text">
                    <h1 class="h1-text">Affordable & Independent</h1>
                    <p class="p-text"><strong>Affordable and Independent:</strong> Making day-to-day travel pocket-friendly, hassle-free and effortless! Become more self-sufficient and free-spirited with Ontrack.</p> 
                    <p class="p-text"><strong>Handpick your style:</strong> Select from the range of models that we offer. <br>
                    Get one that gets your personality going. You have the choice to upgrade it to a different model every month!</p>
                </div>
            </div>
        </div>
        <div class="ref">
                <div class="ref-img">
                    <img class="ref-img" src="../assets/refer-footer1.svg" alt="">
                </div>
                <div class="ref-text">
                    <h1 class="ref-h1">Refer a friend</h1>
                    <p class="ref-p">Click Here To Invite Your Friend To Book A Bike And Earn 250 Ontrack Points.</p>
                </div>
                <div class="ref-btn">
                    <button class="btn btn-primary" type="submit">Refer Now</button>
                </div>
        </div>
    </div>
</template>
<script>
import '../assets/style/style.css'
export default {
    name: "Aboutus"
}
</script>
