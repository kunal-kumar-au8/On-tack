<template>
    <div class="container">
        <h2>
            Copyright Guidelines
        </h2>
        <div>
            <p>This Copyright Guideline, together with our Terms of Use, Privacy Policy, Disclaimer Policy and any other Terms of Use or Guidelines connected with the use of the Platform, constitute a legally binding agreement (the “Agreement”) between You and the Website in relation to Your use of the Services.</p>
            <p><strong>1. Ownership:</strong> All copyrights and trademarks held by the Platform with respect to its logos and content posted on the Website are the Intellectual Properties of Ontrack Technologies Private Ltd operating the Website. The Company owns and controls all the copyright and other intellectual property rights in the Platform and all the copyright and other intellectual property rights in the Website are reserved.</p>
            <p><strong>2. Content:</strong> All the content (including without limitation the design, layout, text, graphics, images, sound, video and all software and source codes connected with the Website) are owned by or licensed to the Company or otherwise used by the Company as permitted by law. The content of the Platform embodies trade secrets and intellectual property rights protected under copyright and other intellectual property laws.</p>
            <p><strong>3. Reproduction:</strong> Any reproduction, modification, distribution, transmission, republication, display, in whole or in part, is prohibited without the express written permission of the Company.</p>
            <p><strong>4. Use of marks:</strong> The use of some material made available on the Platform may be subject to additional terms and conditions contained in any agreement accompanying or relating to such material. These terms and conditions will be made available prior to the use of such material. The Company trademark, any of the Company’s product marks, and any other domain names operated and/or controlled by the Company (“ONTRACK Marks”) are the exclusive property of Ontrack Technologies Private Ltd. You agree not to reproduce, copy, display, upload, post or use in any way the ONTRACK marks, without the prior written permission of Ontrack Technologies Private Ltd.</p>
            <p><strong>5. Acceptable and Unacceptable Use of the Website and Materials:</strong></p>
            <p>5.1. You may:</p>
            <p style="padding-left: 30px;">5.1.1. view pages from our Website in a web browser;</p>
            <p style="padding-left: 30px;">5.1.2. download pages from our Website for caching in a web browser</p>
            <p>5.2. Except as expressly permitted by the other provisions of this notice, you must not download any material from our Website or save any such material to your computer.</p>
            <p>5.3. Except as expressly permitted by this notice, you must not edit or otherwise modify any material on our website</p>
           <p>5.4. Unless you own or control the relevant rights in the material, you must not:</p>
           <p style="padding-left: 30px;">5.4.1. republish material from our Website (including republication on another Website) in violation of this Copyright Guidelines;</p>
           <p style="padding-left: 30px;">5.4.2. sell, rent or sub-license material from our Website;</p>
           <p style="padding-left: 30px;">5.4.3. show any material from our Website in public;</p>
           <p style="padding-left: 30px;">5.4.4. exploit material from our Website for a commercial purpose; or</p>
           <p style="padding-left: 30px;">5.4.5. redistribute material from our Website, save to the extent expressly permitted by this notice.</p>
           <p style="padding-left: 30px;">5.4.6. use our Website in any way or take any action that causes, or may cause, damage to the Website or impairment of the performance, availability or accessibility of the Website</p>
           <p style="padding-left: 30px;">5.4.7. use our Website in any way that is unlawful, illegal, fraudulent or harmful, or in connection with any unlawful, illegal, fraudulent or harmful purpose or activity</p>
           <p style="padding-left: 30px;">5.4.8. use our Website to copy, store, host, transmit, send, use, publish or distribute any material which consists of (or is linked to) any spyware, computer virus, Trojan horse, worm, keystroke logger, rootkit or other malicious computer software; or</p>
           <p style="padding-left: 30px;">5.4.9. conduct any systematic or automated data collection activities (including without limitation scraping, data mining, data extraction and data harvesting) on or in relation to our website without our express written consent.</p>
           <p>5.5. Any violation of this clause shall result in criminal and civil actions taken against you immediately without notice</p>
           <p>5.5. Any violation of this clause shall result in criminal and civil actions taken against you immediately without notice</p>

        </div>
          <div class="ref">
                <div class="ref-img">
                    <img class="ref-img" src="../assets/refer-footer1.svg" alt="">
                </div>
                <div class="ref-text">
                    <h1 class="ref-h1">Refer a friend</h1>
                    <p class="ref-p">Click Here To Invite Your Friend To Book A Bike And Earn 250 Ontrack Points.</p>
                </div>
                <div class="ref-btn">
                    <button class="btn btn-primary" type="submit">Refer Now</button>
                </div>
        </div>

    </div>
</template>

<script>
import "../assets/style/Copyright.css"
export default {
    name:"Copyright"
}
</script>