<template>
    <div class="container">
        <h2>
            Disclaimer Policy
        </h2>
        <div>
            <p>
                This Disclaimer Policy, together with our Terms of Use, Privacy Policy, Copyright Guidelines, and any other Terms of Use or Guidelines connected with the use of the Website, constitute a legally binding agreement (the “Agreement”) between You and the Website in relation to Your use of the Services. The information contained in this Website is for general information purposes only. The information is provided by the Company and the Website and while the Website endeavours to keep the information up to date and correct, it makes no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the Website or the information, products, services, or related graphics contained on the website for any purpose.
                </p>
                <p>
                      Any reliance you place on such information is therefore strictly at your own risk. In no event will the Firm and the Website be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this Website. Through this Website you may be able to link to other websites which are not under the control of the Website. The Website has no control over the nature, content and availability of those sites.
                </p>
              
                <p>
                The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them. Every effort is made to keep the Website up and running smoothly. However, the Website takes no responsibility for, and will not be liable for, the website or the mobile application being temporarily unavailable due to technical issues beyond their control.
            </p>
            <p><strong>Details provided on the Website or Posted at any of its Websites</strong></p>
            <p>The Website claims ownership of the materials you provide to it (including review, feedback and suggestions) or post, upload, input or submit to any Services or its associated services for review by the public, or by the members of any public or private community (“<strong>Submissions</strong>”). However, by posting, uploading, inputting, providing or submitting your Submission, you are granting Ontrack Technologies Private Limited the permission to use your Submission in connection with the operation of their Internet businesses including, without limitation, the licenses rights to copy, distribute, transmit, publicly display, publicly perform, reproduce, edit, translate and reformat your Submission; to publish your name in connection with your Submission; and the right to sublicense such rights to any supplier of the services.</p>
            <p><strong>Disclaimer of Warranty; Limitation of Liability</strong></p>
            <p>You expressly agree that use of the Website is at your Sole risk. Neither the Website, the Firm, its affiliates nor any of their respective employees, agents, third party content providers or licensors warrant that the use of the Website will be uninterrupted or error free; nor do they make any warranty as to the results that may be obtained from the use of the Website or, as to the accuracy, reliability or content of any information, service, or merchandise provided through the Website. The Website is provided on an “As is” basis without warranties of any kind, either express or implied, including, but not limited to, warranties of title or implied warranties of merchantability or fitness for a purpose, other than those warranties which are implied by and incapable of exclusion, restriction or modification under the laws applicable to this Agreement.</p>
            <p>This disclaimer of liability applies to any damages or injury caused by any failure of performance error, omission, interruption, deletion, defect, delay in operation or transmission, computer virus, communication line failure, theft or destruction or unauthorized access to, alteration of or use of record, whether for breach of contract, tortious behaviour, negligence, or under any other cause of action. You specifically acknowledge that the Firm and the Website are not liable for the defamatory, offensive or illegal conduct of other Users or Helps that you connect through the Website or third parties.</p>
            <p>The risk of injury from the foregoing rests entirely with you. In addition to the terms set forth above, the Website, the Firm nor its affiliates, information providers or content partners shall be liable regardless of the cause or duration, for any errors, inaccuracies, omissions, or other defects in the information contained within the Website, or for any other claims or losses arising therefrom or occasioned thereby.</p>
            <p><strong>Disclaimer regarding Software, Documents and Services available on this Website</strong></p>
            <p>In no event shall the Website and/or its respective suppliers shall be liable for any special, indirect or consequential damages or any damages whatsoever resulting from loss of use, data or profits, whether in an action of contract, negligence or other tortious action, arising out of or in connection with the use of performance of software, documents, provision of or failure to provide services, or information available from the services.</p>
            <p><strong>Changed Terms</strong></p>
            <p>The Website shall have the right at any time to change or modify the terms and conditions applicable to your use of the Website, or any part thereof, or to impose new conditions, including, but not limited to, adding fees and charges for use. Such changes, modifications, additions or deletions shall be effective immediately upon notice thereof, which may be given by means including, but not limited to, posting on Website, or by electronic or conventional mail, or by any other means by which you obtain notice thereof. Any use of Website by you after such notice shall be deemed to constitute acceptance by you of such changes, modifications or additions.</p>
        </div>
        <div class="ref">
                <div class="ref-img">
                    <img class="ref-img" src="../assets/refer-footer1.svg" alt="">
                </div>
                <div class="ref-text">
                    <h1 class="ref-h1">Refer a friend</h1>
                    <p class="ref-p">Click Here To Invite Your Friend To Book A Bike And Earn 250 Ontrack Points.</p>
                </div>
                <div class="ref-btn">
                    <button class="btn btn-primary" type="submit">Refer Now</button>
                </div>
        </div>


    </div>
</template>
<script>
import "../assets/style/Disclaimer.css"
export default {
    name:"Disclaimer"
}
</script>